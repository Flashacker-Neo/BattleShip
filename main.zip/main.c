#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#define DEBUG 0
#define COLOR_MAP 1
#define MAP_H 18
#define MAP_W 24
#define MAP_ITEM 4
#define MAP_J1_PLACEMENT 0
#define MAP_J2_PLACEMENT 1
#define MAP_J1_TIRE 2
#define MAP_J2_TIRE 3
#define JOUEUR1 0
#define JOUEUR2 1
#define JOUEUR_NBR 2
#define JOUEUR_ITEM 4 // l'item 0 cause des probl�mes � l'affichage il est donc un espace inutile...
#define JOUEUR_COUP 1
#define JOUEUR_POSY 2
#define JOUEUR_POSX 3

int main()
{
    int player[JOUEUR_NBR][JOUEUR_ITEM] = {0};
    int grille[MAP_H][MAP_W][MAP_ITEM] = {0};
    /*printGame(grille, 0);
        placementBateau(grille, MAP_J1_PLACEMENT);
        printGame(grille, 0);
        int i =0;
        //purge(grille);
        for(i=0; i<432; i++){
            action(grille, player, 3, 0, 1);
        }
        printGame(grille, 2);
       // printf("Nombre de coup :%d", player[JOUEUR2][JOUEUR_COUP]);
        //testRand();*/
        iaVSia(grille,player);
}

void waitFor (unsigned int secs) {
    unsigned int retTime = time(0) + secs;   // Get finishing time.
    while (time(0) < retTime);               // Loop until it arrives.
}
int doRand(int startVal, int endVal){
    waitFor(0.05);
    srand(time(NULL)*rand());
    if(startVal == 0 && endVal == 1){
        return rand() % 2;
    }else{
        return (rand() % ((endVal + startVal -1)))+ startVal;
    }
}
void color(int t,int f){
        HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
            SetConsoleTextAttribute(H,f*16+t);
}
void debug(const char* texte){
    if (DEBUG == 1){
        color(14,0);
        printf("%s\n",texte);
        color(7,0);
    }
}
void purge(int map[MAP_H][MAP_W][MAP_ITEM]){
    int i = 0;
    int j = 0;
    int k = 0;
    for(i=0; i<MAP_H; i++){
        for(j=0; j<MAP_W; j++){
            for(k=0; k<MAP_ITEM; k++){
                map[i][j][k] = 0;
            }
        }
    }
}

void printGame(int map[MAP_H][MAP_W][MAP_ITEM], int niveau){
    int i = 0;
    int j = 0;
    printf("Y/X|A.B.C.D.E.F.G.H.I.J.K.L.M.N.O.P.Q.R.S.T.U.V.W.X.\n");
    for(i=0; i<MAP_H; i++){
            if (i<10){
                printf(" %d |",i);
            }else {
            printf("%d |",i);
            }
        for(j=0; j<MAP_W; j++){
            if (COLOR_MAP == 1){
                if (map[i][j][niveau] == 0){
                    color(3,3);
                }else if (map[i][j][niveau] == 1 || map[i][j][niveau] == 2 || map[i][j][niveau] == 3 || map[i][j][niveau] == 4){
                    color(7,2);
                }else if (map[i][j][niveau] == 9){
                    color(12,12);
                }else if (map[i][j][niveau] == 8){
                    color(11,11);
                }
            }
            printf("%d ", map[i][j][niveau]);
            color(7,0);
        }printf("\n");
    }
}

void placementCorvette(int map[MAP_H][MAP_W][MAP_ITEM], int niveau){
    debug("Entre dans PlacementCorvette");
    int placement = 0;
    int coordX = 0;
    int coordY = 0;
    while (placement == 0){
        coordX = doRand(0,MAP_W-1);
        coordY = doRand(0,MAP_H-1);
        if (map[coordY][coordX][niveau] == 0){
            map[coordY][coordX][niveau] = 1;
            placement = 1;
            debug("Bateau Corvette placer");
            printf("coordX %d, coordY %d\n",coordX,coordY);
        }
    }
}

void placementDestroyer(int map[MAP_H][MAP_W][MAP_ITEM], int niveau){
    debug("Entre dans PlacementDestroyer");
    int placement = 0;
    int coordX = 0;
    int coordY = 0;
    int sens = 0;
    while (placement == 0){
        coordX = doRand(0,MAP_W-1);
        coordY = doRand(0,MAP_H-1);
        sens = doRand(0,1);
        switch(sens){
        case 0:
            if (coordY+2 < MAP_H && map[coordY][coordX][niveau] == 0 && map[coordY+1][coordX][niveau] == 0 && map[coordY+2][coordX][niveau] == 0){
                map[coordY][coordX][niveau] = 2;
                map[coordY+1][coordX][niveau] = 2;
                map[coordY+2][coordX][niveau] = 2;
                placement = 1;
                debug("Bateau Destroyer placer");
                printf("coordX %d, coordY %d, sens %d\n",coordX,coordY,sens);
            }
            break;
        case 1:
            if (coordX+2 < MAP_H && map[coordY][coordX][niveau] == 0&& map[coordY][coordX+1][niveau] == 0 && map[coordY][coordX+2][niveau] == 0 ){
                map[coordY][coordX][niveau] = 2;
                map[coordY][coordX+1][niveau] = 2;
                map[coordY][coordX+2][niveau] = 2;
                placement = 1;
                debug("Bateau Destroyer placer");
                printf("coordX %d, coordY %d, sens %d\n",coordX,coordY,sens);
            }
            break;
        default:
            debug("Parametre invalide !");
            placement = 0;
            break;
        }
    }
}

void placementCroiseur(int map[MAP_H][MAP_W][MAP_ITEM], int niveau){
    debug("Entre dans PlacementCroiseur");
    int placement = 0;
    int coordX = 0;
    int coordY = 0;
    int sens = 0;
    while (placement == 0){
        coordX = doRand(0,MAP_W-1);
        coordY = doRand(0,MAP_H-1);
        sens = doRand(0,1);
        switch(sens){
        case 0:
            if (coordY+3 < MAP_H && map[coordY][coordX][niveau] == 0 && map[coordY+1][coordX][niveau] == 0
                && map[coordY+2][coordX][niveau] == 0 && map[coordY+3][coordX][niveau] == 0){
                map[coordY][coordX][niveau] = 3;
                map[coordY+1][coordX][niveau] = 3;
                map[coordY+2][coordX][niveau] = 3;
                map[coordY+3][coordX][niveau] = 3;
                placement = 1;
                debug("Bateau Croiseur placer");
                printf("coordX %d, coordY %d, sens %d\n",coordX,coordY,sens);
            }
            break;
        case 1:
            if (coordX+3 < MAP_W && map[coordY][coordX][niveau] == 0&& map[coordY][coordX+1][niveau] == 0
                && map[coordY][coordX+2][niveau] == 0 && map[coordY][coordX+3][niveau] == 0){
                map[coordY][coordX][niveau] = 3;
                map[coordY][coordX+1][niveau] = 3;
                map[coordY][coordX+2][niveau] = 3;
                map[coordY][coordX+3][niveau] = 3;
                placement = 1;
                debug("Bateau Croiseur placer");
                printf("coordX %d, coordY %d, sens %d\n",coordX,coordY,sens);
            }
            break;
        default:
            debug("Parametre invalide !");
            placement = 0;
            break;
        }
    }
}

void placementPorteAvion(int map[MAP_H][MAP_W][MAP_ITEM], int niveau){
    debug("Entre dans PlacementPorteAvion");
    int placement = 0;
    int coordX = 0;
    int coordY = 0;
    int sens = 0;
    while (placement == 0){
        coordX = doRand(0,MAP_W-1);
        coordY = doRand(0,MAP_H-1);
        sens = doRand(0,1);
        switch(sens){
        case 0:
            if (coordY+5 < MAP_H && map[coordY][coordX][niveau] == 0 && map[coordY+1][coordX][niveau] == 0 && map[coordY+2][coordX][niveau] == 0
                && map[coordY+3][coordX][niveau] == 0 && map[coordY+4][coordX][niveau] == 0 && map[coordY+5][coordX][niveau] == 0){
                map[coordY][coordX][niveau] = 4;
                map[coordY+1][coordX][niveau] = 4;
                map[coordY+2][coordX][niveau] = 4;
                map[coordY+3][coordX][niveau] = 4;
                map[coordY+4][coordX][niveau] = 4;
                map[coordY+5][coordX][niveau] = 4;
                placement = 1;
                debug("Bateau Porte-avion placer");
                printf("coordX %d, coordY %d, sens %d\n",coordX,coordY,sens);
            }
            break;
        case 1:
            if (coordX+5 < MAP_W && map[coordY][coordX][niveau] == 0&& map[coordY][coordX+1][niveau] == 0 && map[coordY][coordX+2][niveau] == 0
                && map[coordY][coordX+3][niveau] == 0 && map[coordY][coordX+4][niveau] == 0 && map[coordY][coordX+5][niveau] == 0){
                map[coordY][coordX][niveau] = 4;
                map[coordY][coordX+1][niveau] = 4;
                map[coordY][coordX+2][niveau] = 4;
                map[coordY][coordX+3][niveau] = 4;
                map[coordY][coordX+4][niveau] = 4;
                map[coordY][coordX+5][niveau] = 4;
                placement = 1;
                debug("Bateau Porte-avion placer");
                printf("coordX %d, coordY %d, sens %d\n",coordX,coordY,sens);
            }
            break;
        default:
            debug("Parametre invalide !");
            placement = 0;
            break;
        }
    }
}

void placementBateau(int map[MAP_H][MAP_W][MAP_ITEM], int niveau){
    placementCorvette(map, niveau);
    placementDestroyer(map, niveau);
    placementDestroyer(map, niveau);
    placementCroiseur(map, niveau);
    placementCroiseur(map, niveau);
    placementPorteAvion(map, niveau);
}

void action(int map[MAP_H][MAP_W][MAP_ITEM], int player[JOUEUR_NBR][JOUEUR_ITEM], int J1Tire, int J2Placement, int joueur){
    debug("Entre dans Action");
    int tire = 0;
    int coordX = 0;
    int coordY = 0;
    while (tire == 0){
        coordX = doRand(0,MAP_W+1);
        coordY = doRand(0,MAP_H+1);
        if (map[coordY][coordX][J1Tire] == 0){
            tire = 1;
        }
    }
    if (map[coordY][coordX][J2Placement] == 1 || map[coordY][coordX][J2Placement] == 2
        || map[coordY][coordX][J2Placement] == 3 || map[coordY][coordX][J2Placement] == 4 ){
        map[coordY][coordX][J1Tire] = 9;
        printf("Bateau toucher !\n");
        debug("Action tire toucher effectuer");
        printf("coordX %d, coordY %d\n",coordX,coordY);
    }else {
        map[coordY][coordX][J1Tire] = 8;
        printf("Tire rater !\n");
        debug("Action tire rate effectuer");
        printf("coordX %d, coordY %d\n",coordX,coordY);
    }
    if (map[coordY][coordX][J1Tire] == 9){
        player[joueur][JOUEUR_COUP] ++ ;
    }

        /*printGame(map,2);
        printf("\n");
        printGame(map,3);*/
}

void iaVSia(int map[MAP_H][MAP_W][MAP_ITEM], int player[JOUEUR_NBR][JOUEUR_ITEM]){
    placementBateau(map, MAP_J1_PLACEMENT);
    printGame(map, MAP_J1_PLACEMENT);
    placementBateau(map, MAP_J2_PLACEMENT);
    printGame(map, MAP_J2_PLACEMENT);
    while (player[JOUEUR1][JOUEUR_COUP] < 21 && player[JOUEUR2][JOUEUR_COUP] < 21){
        printf("Tour Joueur 1\n");
        action(map, player, MAP_J1_TIRE, MAP_J2_PLACEMENT, JOUEUR1);
        printf("Joueur 1 : %d\n",player[JOUEUR1][JOUEUR_COUP]);
        printf("Tour Joueur 2\n");
        action(map, player, MAP_J2_TIRE, MAP_J1_PLACEMENT, JOUEUR2);
        printf("Joueur 2 : %d\n",player[JOUEUR2][JOUEUR_COUP]);
    }
    if (player[JOUEUR1][JOUEUR_COUP] == 21){
        printf("\nLe Joueur 1 a gagner !!\n");
        printGame(map, MAP_J1_TIRE);
    }else {
        printf("\nLe Joueur 2 a gagner !!\n");
        printGame(map, MAP_J2_TIRE);
    }
}

int testRand(){
    #define numberOfRand 10000
    #define numberOfValues 100
    int i = 0;
    int j = 0;
    int tab[numberOfRand] = {0};
    for(i = 0; i < numberOfRand; i++){
        tab[i] = doRand(0,numberOfValues);
    }

    int result[numberOfValues] = {0};
    for(i = 0; i < numberOfValues; i++){
        for(j = 0; j < numberOfRand; j++){
            if(tab[j] == i){
                result[i]++;
            }
        }
    }

    for(i = 0; i < numberOfValues; i++){
        printf("Valeur %d occurence %d\n",i,result[i]);
    }
}
